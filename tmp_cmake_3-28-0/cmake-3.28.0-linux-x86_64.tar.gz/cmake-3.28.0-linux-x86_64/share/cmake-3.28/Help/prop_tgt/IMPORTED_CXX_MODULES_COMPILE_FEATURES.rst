IMPORTED_CXX_MODULES_COMPILE_FEATURES
-------------------------------------

.. versionadded:: 3.28

Compiler features enabled for this ``IMPORTED`` target's C++ modules.

The value of this property is used by the generators to set the include
paths for the compiler.
