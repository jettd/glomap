INTERFACE_LINK_DIRECTORIES
--------------------------

.. versionadded:: 3.13

.. |property_name| replace:: link directories
.. |command_name| replace:: :command:`target_link_directories`
.. |PROPERTY_INTERFACE_NAME| replace:: ``INTERFACE_LINK_DIRECTORIES``
.. |PROPERTY_LINK| replace:: :prop_tgt:`LINK_DIRECTORIES`
.. include:: INTERFACE_BUILD_PROPERTY.txt
