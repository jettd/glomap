EXPORT_COMPILE_COMMANDS
-----------------------

.. versionadded:: 3.20

Enable/Disable output of compile commands during generation for a target.

This property is initialized by the value of the variable
:variable:`CMAKE_EXPORT_COMPILE_COMMANDS` if it is set when a target is created.
