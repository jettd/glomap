ANDROID_JAVA_SOURCE_DIR
-----------------------

.. versionadded:: 3.4

Set the Android property that defines the Java source code root directories.
This a string property that contains the directory paths separated by semicolon.
This property is initialized by the value of the
:variable:`CMAKE_ANDROID_JAVA_SOURCE_DIR` variable if it is set
when a target is created.
